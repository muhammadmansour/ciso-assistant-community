import{p}from"./YAPe4s4R.js";const o=p;export{o as p};
