import{p}from"./B38biiEb.js";const o=p;export{o as p};
