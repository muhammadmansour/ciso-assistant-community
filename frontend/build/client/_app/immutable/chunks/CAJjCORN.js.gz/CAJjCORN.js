import{p}from"./ng3-XvhC.js";const o=p;export{o as p};
