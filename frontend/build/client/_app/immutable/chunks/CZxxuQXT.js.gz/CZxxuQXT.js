import{p}from"./CVPAKgDb.js";const o=p;export{o as p};
