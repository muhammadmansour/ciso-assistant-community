import{p}from"./DjUEmYqv.js";const o=p;export{o as p};
