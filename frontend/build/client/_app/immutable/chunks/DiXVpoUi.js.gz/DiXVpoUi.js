import{p}from"./CpFnAMUI.js";const o=p;export{o as p};
