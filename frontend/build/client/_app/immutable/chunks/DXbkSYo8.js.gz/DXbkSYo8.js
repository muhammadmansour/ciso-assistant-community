import{p}from"./CIQ63Ha5.js";const o=p;export{o as p};
