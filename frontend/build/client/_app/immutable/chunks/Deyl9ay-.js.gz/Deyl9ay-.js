import{p}from"./-4awm6M-.js";const o=p;export{o as p};
