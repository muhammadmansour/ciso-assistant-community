import{p}from"./BJgYCOde.js";const o=p;export{o as p};
