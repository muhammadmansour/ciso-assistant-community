import{p}from"./DXF9TMZi.js";const o=p;export{o as p};
