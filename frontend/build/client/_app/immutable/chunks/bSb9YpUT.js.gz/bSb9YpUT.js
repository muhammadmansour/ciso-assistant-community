import{p}from"./CHJQfzF4.js";const o=p;export{o as p};
