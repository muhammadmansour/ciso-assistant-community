import{p}from"./DYotTY_m.js";const o=p;export{o as p};
