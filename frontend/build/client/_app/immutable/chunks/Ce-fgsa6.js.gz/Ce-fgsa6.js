import{p}from"./1kTZNG77.js";const o=p;export{o as p};
