import{p}from"./CKO4dPCJ.js";const o=p;export{o as p};
