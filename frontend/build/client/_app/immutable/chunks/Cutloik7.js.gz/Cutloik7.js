import{p}from"./DJUALYxg.js";const o=p;export{o as p};
