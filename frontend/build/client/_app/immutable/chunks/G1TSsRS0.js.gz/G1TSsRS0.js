import{p}from"./jLGvEFfk.js";const o=p;export{o as p};
