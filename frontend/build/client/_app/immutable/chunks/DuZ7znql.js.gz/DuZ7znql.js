import{p}from"./B7KUphyC.js";const o=p;export{o as p};
