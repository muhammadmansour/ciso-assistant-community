import{p}from"./CumOB_G-.js";const o=p;export{o as p};
