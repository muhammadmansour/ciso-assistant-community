import{L as m}from"../chunks/BlJKg5jC.js";export{m as component};
