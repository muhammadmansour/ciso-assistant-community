import{L as m}from"../chunks/BXEVpocf.js";export{m as component};
